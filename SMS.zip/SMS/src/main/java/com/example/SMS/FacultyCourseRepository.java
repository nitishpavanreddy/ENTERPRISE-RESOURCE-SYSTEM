package com.example.SMS;

import org.springframework.data.repository.CrudRepository;

public interface FacultyCourseRepository extends CrudRepository<FacultyCourse, Long> {
}
