package com.example.SMS;

import org.springframework.stereotype.Service;

@Service
public class StudentCourseService {

}
